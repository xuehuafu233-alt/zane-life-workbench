#!/usr/bin/env python3
"""Install a verified ZANE edition; reuse exact shared skills, protect local changes."""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tempfile

SHARED = ['zane-workbench-curator', 'zane-question-intent-translator',
          'zane-agent-identity-card-builder', 'zane-self-insight']
EDITIONS = {'work': ['zane-workbench-work', *SHARED],
            'life': ['zane-workbench', *SHARED],
            'career': ['zane-workbench-career', *SHARED]}


def files(folder):
    result = {}
    for p in folder.rglob('*'):
        if p.is_symlink():
            raise ValueError('Unexpected symlink: ' + p.name)
        if p.is_file():
            result[p.relative_to(folder).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    return result


def verify(source):
    if source.is_symlink():
        raise ValueError('Package root must be a real directory')
    manifest = json.loads((source / 'package-manifest.json').read_text(encoding='utf-8'))
    expected = EDITIONS.get(manifest.get('edition'))
    legacy_life = (manifest.get('edition') == 'life' and manifest.get('version') in {'0.2.0', '0.3.0', '0.3.1'}
                   and manifest.get('skills') == ['zane-workbench', 'zane-workbench-work', *SHARED])
    if manifest.get('schema') != 2 or (manifest.get('skills') != expected and not legacy_life):
        raise ValueError('Unknown package schema or edition')
    actual = files(source)
    actual.pop('package-manifest.json', None)
    if actual != manifest['files']:
        raise ValueError('Package integrity mismatch; extract a fresh trusted archive')
    for rel in manifest['files']:
        p = PurePosixPath(rel)
        if p.is_absolute() or '..' in p.parts or '\\' in rel:
            raise ValueError('Unsafe manifest path')
    for name in manifest['skills']:
        if files(source / 'skills' / name) != manifest['skill_files'][name]:
            raise ValueError('Skill integrity mismatch: ' + name)
    return manifest


@contextmanager
def lock(destination):
    marker = destination / '.zane-install-lock'
    try:
        marker.mkdir()
    except FileExistsError:
        raise ValueError('Another installer or a stale lock exists; inspect before retrying')
    try:
        yield
    finally:
        marker.rmdir()


def install(source, destination, upgrade=False):
    source = source.absolute()
    manifest = verify(source)
    destination = destination.expanduser().absolute()
    if destination.resolve().is_relative_to(source.resolve()) or source.resolve().is_relative_to(destination.resolve()):
        raise ValueError('Package and host skill directory must not contain one another')
    if destination.is_symlink():
        raise ValueError('Choose a real host skill directory')
    # Read-only preflight before any destination creation or mutations.
    receipt_path = destination / '.zane-installed.json'
    if receipt_path.is_symlink():
        raise ValueError('Receipt must not be a symlink')
    receipt_bytes = receipt_path.read_bytes() if receipt_path.exists() else None
    receipt = json.loads(receipt_bytes) if receipt_bytes else {'schema': 1, 'skills': {}}

    def plan():
        changes = []
        for name in manifest['skills']:
            target = destination / name
            expected = manifest['skill_files'][name]
            if target.exists() or target.is_symlink():
                if not target.is_dir():
                    raise ValueError('Existing path conflicts: ' + name)
                current = files(target)
                if current == expected:
                    continue
                if not upgrade:
                    raise ValueError('Existing skill differs; no files installed: ' + name)
                prior = receipt['skills'].get(name)
                if prior:
                    incoming = tuple(int(x) for x in manifest['versions'][name].split('.'))
                    installed_version = tuple(int(x) for x in prior['version'].split('.'))
                    if incoming < installed_version:
                        raise ValueError('Refusing shared skill downgrade: ' + name)
                if target.is_symlink() or not prior or current != prior.get('files'):
                    raise ValueError('Unmanaged or locally edited skill; preserve and compare: ' + name)
                changes.append((name, True))
            else:
                changes.append((name, False))
        return changes

    planned = plan()
    destination.mkdir(parents=True, exist_ok=True)
    with lock(destination):
        if (receipt_path.read_bytes() if receipt_path.exists() else None) != receipt_bytes:
            raise ValueError("Another installation changed the receipt; retry")
        if planned != plan():
            raise ValueError('Destination changed; retry from fresh state')
        if not planned:
            return 0
        backup = destination / '.zane-install-backup'
        if backup.is_symlink():
            raise ValueError('Backup path must not be a symlink')
        backup.mkdir(exist_ok=True)
        run = Path(tempfile.mkdtemp(prefix=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S-'), dir=backup))
        before_receipt = receipt_path.read_bytes() if receipt_path.exists() else None
        if before_receipt is not None:
            (run / 'receipt.before.json').write_bytes(before_receipt)
        installed = []
        moved = []
        try:
            with tempfile.TemporaryDirectory(prefix='.zane-stage-', dir=destination) as temp:
                stage = Path(temp)
                for name, replacing in planned:
                    shutil.copytree(source / 'skills' / name, stage / name)
                # Revalidate existing content after staging and before replacing anything.
                if planned != plan():
                    raise ValueError('Destination changed during staging')
                for name, replacing in planned:
                    target = destination / name
                    if replacing:
                        target.rename(run / name)
                        moved.append(name)
                    (stage / name).rename(target)
                    installed.append(name)
            for name in manifest['skills']:
                receipt['skills'][name] = {'version': manifest['versions'][name],
                                          'files': manifest['skill_files'][name],
                                          'package': manifest['package']}
            receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
            (run / 'rollback.json').write_text(json.dumps({
                'installed': installed, 'replaced': moved,
                'after': {n: manifest['skill_files'][n] for n in installed},
                'receipt_sha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
                'had_receipt': before_receipt is not None}, ensure_ascii=False, indent=2))
        except Exception:
            # Preserve attempted new versions; restore old files without permanent deletion.
            for name in reversed(installed):
                (destination / name).rename(run / (name + '.attempt'))
            for name in moved:
                (run / name).rename(destination / name)
            if before_receipt is not None:
                receipt_path.write_bytes(before_receipt)
            elif receipt_path.exists():
                receipt_path.rename(run / 'receipt.attempt.json')
            raise
        print('Saved rollback checkpoint: ' + str(run))
    return len(planned)


def rollback(destination, checkpoint):
    destination = destination.expanduser().absolute()
    checkpoint = checkpoint.expanduser().absolute()
    if destination.is_symlink() or checkpoint.is_symlink() or checkpoint.parent.is_symlink() or checkpoint.parent != destination / '.zane-install-backup':
        raise ValueError('Use a checkpoint in this host skill directory')
    info = json.loads((checkpoint / 'rollback.json').read_text())
    receipt_path = destination / '.zane-installed.json'
    with lock(destination):
        if receipt_path.is_symlink() or hashlib.sha256(receipt_path.read_bytes()).hexdigest() != info['receipt_sha256']:
            raise ValueError('Receipt changed since checkpoint; do not overwrite later installs')
        for name in info['installed']:
            if name not in set(sum(EDITIONS.values(), [])):
                raise ValueError('Unknown checkpoint skill')
            target = destination / name
            if target.is_symlink() or files(target) != info['after'][name]:
                raise ValueError('Local changes after install; compare manually: ' + name)
        for name in info['replaced']:
            if not (checkpoint / name).is_dir() or (checkpoint / name).is_symlink():
                raise ValueError('Missing backup')
        kept = checkpoint / 'rolled-back-content'
        kept.mkdir()
        for name in info['installed']:
            (destination / name).rename(kept / name)
        for name in info['replaced']:
            (checkpoint / name).rename(destination / name)
        receipt_path.rename(kept / 'receipt.json')
        if info['had_receipt']:
            shutil.copy2(checkpoint / 'receipt.before.json', receipt_path)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--skills-dir', type=Path, required=True)
    p.add_argument('--upgrade', action='store_true')
    p.add_argument('--rollback', type=Path)
    args = p.parse_args()
    try:
        if args.rollback:
            rollback(args.skills_dir, args.rollback)
            print('Rolled back; replaced content retained in checkpoint.')
        else:
            n = install(Path(__file__).resolve().parent, args.skills_dir, args.upgrade)
            print('Installed or upgraded {} skills. Reload the AI host and read the entry Skill.'.format(n))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        p.exit(2, 'Stopped: ' + str(exc) + '\n')


if __name__ == '__main__':
    main()
